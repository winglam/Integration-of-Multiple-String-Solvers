package ANTLR::Runtime::CharStream;

use Readonly;
use Carp;

use strict;
use warnings;

Readonly our $EOF => -1;
sub EOF { return $EOF; }

sub substring {
}

sub LT {
}

sub get_line {
}

sub set_line {
}

sub set_char_position_in_line {
}

sub get_char_position_in_line {
}

1;
