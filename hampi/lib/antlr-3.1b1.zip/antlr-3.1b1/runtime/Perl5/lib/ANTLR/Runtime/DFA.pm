package ANTLR::Runtime::DFA;

use strict;
use warnings;

1;
