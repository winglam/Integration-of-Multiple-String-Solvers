package ANTLR::Runtime;

use strict;
use warnings;

our $VERSION = '0.01';


1;

__END__

=head1 NAME

ANTLR::Runtime - ANTLR Runtime for Perl 5
