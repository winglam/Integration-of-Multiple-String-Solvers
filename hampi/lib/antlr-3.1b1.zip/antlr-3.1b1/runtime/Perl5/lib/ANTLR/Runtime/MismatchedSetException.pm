package ANTLR::Runtime::MismatchedSetException;

use strict;
use warnings;

use base qw( ANTLR::Runtime::Exception );

1;
